/**
 * API Service — Connects frontend to FastAPI backend
 */

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

function getAuthToken() {
  return localStorage.getItem('smartcrop_token');
}

async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  const token = getAuthToken();

  // Build headers
  const headers = {};
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const res = await fetch(url, {
      headers,
      ...options,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || `API error: ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    if (err.name === 'TypeError' && err.message.includes('fetch')) {
      throw new Error('Cannot connect to backend. Make sure the server is running on port 8000.');
    }
    throw err;
  }
}

// ── Auth ──────────────────────────────────────────────

export async function registerUser(data) {
  return apiCall('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function loginUser(data) {
  return apiCall('/auth/login', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function googleLogin(accessToken) {
  return apiCall('/auth/google', {
    method: 'POST',
    body: JSON.stringify({ access_token: accessToken }),
  });
}

// ── Profile ───────────────────────────────────────────

export async function getProfile() {
  return apiCall('/profile');
}

export async function saveProfile(data) {
  return apiCall('/profile', {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function deleteProfile() {
  return apiCall('/profile', { method: 'DELETE' });
}

// ── Fields ────────────────────────────────────────────

export async function getFields() {
  return apiCall('/fields');
}

export async function getFieldById(fieldId) {
  return apiCall(`/fields/${fieldId}`);
}

export async function createField(data) {
  return apiCall('/fields', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateField(fieldId, data) {
  return apiCall(`/fields/${fieldId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function deleteFieldById(fieldId) {
  return apiCall(`/fields/${fieldId}`, { method: 'DELETE' });
}

// ── Health ────────────────────────────────────────────

export async function healthCheck() {
  return apiCall('/health');
}

// ── Crop Recommendation ──────────────────────────────

export async function recommendCrop(data) {
  return apiCall('/recommend/crop', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function predictYield(data) {
  return apiCall('/predict/yield', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function predictPrice(data) {
  return apiCall('/predict/price', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getYieldDistricts(state) {
  return apiCall(`/yield/districts?state=${encodeURIComponent(state)}`);
}

export async function getCrops() {
  return apiCall('/crops');
}

export async function getWeather(lat, lon) {
  return apiCall(`/weather/${lat}/${lon}`);
}

export async function getMarketPrices(commodity = 'Wheat', state = '', district = '', market = '', days = 90) {
  const params = new URLSearchParams({ commodity, state, district, market, days: String(days) });
  return apiCall(`/market/prices?${params}`);
}

// ── Location Detection ────────────────────────────────

export async function detectLocation(ip = '') {
  const params = ip ? `?ip=${ip}` : '';
  return apiCall(`/location/detect${params}`);
}

// ── Weather Alerts ────────────────────────────────────

export async function getWeatherAlerts(lat, lon, days = 2) {
  return apiCall(`/weather/alerts/${lat}/${lon}?days=${days}`);
}

export async function getMyAlerts(limit = 10) {
  return apiCall(`/alerts/my-alerts?limit=${limit}`);
}

// ── Market Metadata & Commodities ─────────────────────

export async function getMarketMetadata() {
  return apiCall('/market/metadata');
}

export async function getMarketCommodities(state = '', district = '') {
  return apiCall(`/market/commodities?state=${encodeURIComponent(state)}&district=${encodeURIComponent(district)}`);
}

// ── State-Aware Endpoints ─────────────────────────────

export async function getStates() {
  return apiCall('/states');
}

export async function getCropsByState(state) {
  return apiCall(`/crops/by-state/${encodeURIComponent(state)}`);
}

export async function getSoilTypes() {
  return apiCall('/soil-types');
}

// ── Disease Detection ─────────────────────────────────

export async function getDiseaseCrops() {
  return apiCall('/disease/crops');
}

export async function detectDisease(crop, imageFile) {
  const formData = new FormData();
  formData.append('crop', crop);
  formData.append('image', imageFile);
  return apiCall('/disease/detect', {
    method: 'POST',
    body: formData,
  });
}

// ── Recommendation History ────────────────────────────

export async function getRecommendationHistory(limit = 20) {
  return apiCall(`/recommendations/history?limit=${limit}`);
}

export async function deleteRecommendationHistory(recordId) {
  return apiCall(`/recommendations/history/${recordId}`, { method: 'DELETE' });
}

// ── Disease Scan History ──────────────────────────────

export async function getDiseaseHistory(limit = 20) {
  return apiCall(`/disease/history?limit=${limit}`);
}

export async function deleteDiseaseHistory(scanId) {
  return apiCall(`/disease/history/${scanId}`, { method: 'DELETE' });
}

// ── Crop Plans (Rotation Planner) ─────────────────────

export async function getCropPlans(year = null, grouped = true) {
  let url = `/plans?grouped=${grouped}`;
  if (year) url += `&year=${year}`;
  return apiCall(url);
}

export async function createCropPlan(data) {
  return apiCall('/plans', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function updateCropPlan(planId, data) {
  return apiCall(`/plans/${planId}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  });
}

export async function deleteCropPlan(planId) {
  return apiCall(`/plans/${planId}`, { method: 'DELETE' });
}

// ── Pest Alerts ───────────────────────────────────────

export async function getPestAlerts(state, season = '') {
  return apiCall(`/pests/alerts?state=${encodeURIComponent(state)}&season=${season}`);
}

export async function getPestForCrop(cropKey) {
  return apiCall(`/pests/crop/${encodeURIComponent(cropKey)}`);
}

export async function getSeasonInfo() {
  return apiCall('/pests/season');
}

export async function getPestStates() {
  return apiCall('/pests/states');
}

// ── Fertilizer ────────────────────────────────────────

export async function recommendFertilizer(data) {
  return apiCall('/fertilizer/recommend', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getOrganicRemedies(data) {
  return apiCall('/fertilizer/organic', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getFertilizerMetadata() {
  return apiCall('/fertilizer/metadata');
}

// ── Community Chat ────────────────────────────────────

export async function getCommunityMessages(limit = 50, before = null) {
  let url = `/community/messages?limit=${limit}`;
  if (before) url += `&before=${before}`;
  return apiCall(url);
}

export async function sendCommunityMessage(message) {
  return apiCall('/community/messages', {
    method: 'POST',
    body: JSON.stringify({ message }),
  });
}

export async function getOnlineCount() {
  return apiCall('/community/online');
}

// ── Feedback ──────────────────────────────────────────

export async function submitFeedback(data) {
  return apiCall('/feedback', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

export async function getFeedbackHistory(limit = 10) {
  return apiCall(`/feedback?limit=${limit}`);
}

// ── Speech-to-Text (Azure) ────────────────────────────

export async function speechToText(audioBlob, language = 'en-IN') {
  const formData = new FormData();
  formData.append('audio', audioBlob, 'recording.wav');
  formData.append('language', language);

  return apiCall('/speech-to-text', {
    method: 'POST',
    body: formData,
  });
}


const api = {
  // Auth
  registerUser, loginUser, googleLogin,
  // Profile
  getProfile, saveProfile, deleteProfile,
  // Fields
  getFields, getFieldById, createField, updateField, deleteFieldById,
  // Health
  healthCheck,
  // ML
  recommendCrop, predictYield, predictPrice, getYieldDistricts, getCrops,
  // Location
  detectLocation,
  // Weather
  getWeather, getWeatherAlerts, getMyAlerts,
  // Market
  getMarketPrices, getMarketMetadata, getMarketCommodities,
  // States
  getStates, getCropsByState, getSoilTypes,
  // Disease
  getDiseaseCrops, detectDisease,
  // History
  getRecommendationHistory, deleteRecommendationHistory,
  getDiseaseHistory, deleteDiseaseHistory,
  // Plans
  getCropPlans, createCropPlan, updateCropPlan, deleteCropPlan,
  // Pests
  getPestAlerts, getPestForCrop, getSeasonInfo, getPestStates,
  // Fertilizer
  recommendFertilizer, getOrganicRemedies, getFertilizerMetadata,
  // Community
  getCommunityMessages, sendCommunityMessage, getOnlineCount,
  // Feedback
  submitFeedback, getFeedbackHistory,
  // Speech
  speechToText,
};

export default api;

